package edu.umsl.interfaceproject;

public class App {

	public static void main(String[] args) {
		
		Shape shape = new Circle();
		shape.calcArea();
		
		shape = new Square();
		shape.calcArea();
		
		shape = new Rectangle();
		shape.calcArea();
		
		
		
		
		
		

	}

}
