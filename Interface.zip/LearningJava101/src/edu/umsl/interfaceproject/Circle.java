package edu.umsl.interfaceproject;

public class Circle implements Shape {
	
	public int radius = 3;
	

	public void calcArea() {
		
		System.out.println("The Area of a Circle is");
		System.out.println(radius*diameter);
		
	}
	

	
	

}
