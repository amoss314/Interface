package edu.umsl.interfaceproject;

public class Rectangle implements Shape {
	
	public int length = 5;
	public int width = 6;

	public void calcArea() {
		
		System.out.println("The Area of a Rectangle is");
		System.out.println(length*width);
		
		
		
	}

}
