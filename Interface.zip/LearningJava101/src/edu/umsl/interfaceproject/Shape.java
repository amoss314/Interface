package edu.umsl.interfaceproject;

public interface Shape {
	
	public void calcArea();
	public static final int diameter = (int) Math.PI;
	
	
	
	
	
	
	
	

}
