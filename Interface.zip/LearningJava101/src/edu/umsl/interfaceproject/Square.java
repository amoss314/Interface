package edu.umsl.interfaceproject;

public class Square implements Shape {
	
	public int side = 5;

	public void calcArea() {
	
		System.out.println("The Area of a Square is");
		System.out.println(side*side);
		
		
		
	}

}
